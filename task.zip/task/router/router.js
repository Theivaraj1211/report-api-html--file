const express = require('express');
const router = express.Router();
const studentController = require('../controlller/studentController');
const markController = require('../controlller/markController');
const teacherController = require('../controlller/teacherController');

// Student routes
router.post('/students', studentController.createStudent);
router.get('/students', studentController.getAllStudents);
router.get('/students/:id', studentController.getStudentById);
router.put('/students/:id', studentController.updateStudentById);
router.delete('/students/:id', studentController.deleteStudentById);

// Mark routes
router.post('/marks', markController.createMark);
router.get('/marks', markController.getAllMarks);
router.get('/marks/:id', markController.getMarkById);
router.put('/marks/:id', markController.updateMarkById);
router.delete('/marks/:id', markController.deleteMarkById);

// Teacher routes
router.post('/teachers', teacherController.createTeacher);
router.get('/teachers', teacherController.getAllTeachers);
router.get('/teachers/:id', teacherController.getTeacherById);
router.put('/teachers/:id', teacherController.updateTeacherById);
router.delete('/teachers/:id', teacherController.deleteTeacherById);

module.exports = router;
