const express = require('express');
const connectDB = require('./connection/connection');
const routes = require('./router/router');
const db = require("./connection/connection");
const app = express();
const port = 3001;

// Connect to the MongoDB database
//connectDB();
db.on("error", console.error.bind(console, "MongoDB connection error:"));
db.once("open", () => {
    console.log("Connected to MongoDB");
});
// Middleware to parse JSON
app.use(express.json());

// Use the routes defined in the router file
app.use('/api/v1', routes);

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
