const Mark = require('../connection/module/markschema');

// Create a new mark
exports.createMark = async (req, res) => {
    try {
        const newMark = new Mark(req.body);
        await newMark.save();
        res.status(201).json(newMark);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Get all marks
exports.getAllMarks = async (req, res) => {
    try {
        const marks = await Mark.find();
        res.status(200).json(marks);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Get mark by ID
exports.getMarkById = async (req, res) => {
    try {
        const mark = await Mark.findById(req.params.id);
        res.status(200).json(mark);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Update mark by ID
exports.updateMarkById = async (req, res) => {
    try {
        const updatedMark = await Mark.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true }
        );
        res.status(200).json(updatedMark);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Delete mark by ID
exports.deleteMarkById = async (req, res) => {
    try {
        await Mark.findByIdAndDelete(req.params.id);
        res.status(204).end();
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
