const mongoose = require('mongoose');

const markSchema = new mongoose.Schema({
    studentId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Student',
    },
    subject: {
        type: String,
    },
    score: {
        type: Number,
    },
    // Add any other fields as needed
});

const Mark = mongoose.model('Mark', markSchema);

module.exports = Mark;
