const mongoose = require('mongoose');
const connectionString = `mongodb://127.0.0.1:27017/test`
try {
    mongoose.connect(connectionString, { useNewUrlParser: true, useUnifiedTopology: true });
} catch (error) {
    // Check if the error is a MongoNetworkError.
    if (error.name === "MongoNetworkError" && error.message.includes("ECONNREFUSED")) {
        // The MongoDB server is not running.
        console.log("The MongoDB server is not running.");
    } else {
        // Something else went wrong.
        console.log(error);
    }
}
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
    console.log('Connected to MongoDB');
});

module.exports = db;