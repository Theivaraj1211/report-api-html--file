const mongoose = require('mongoose');

const teacherSchema = new mongoose.Schema({
    name: {
        type: String,
    },
    subject: {
        type: String,
    },
    // Add any other fields as needed
});

const Teacher = mongoose.model('Teacher', teacherSchema);

module.exports = Teacher;
